// Lambda function to handle RESTful API requests via API Gateway
// Author: Rômulo Azevedo (Student ID: L00188348)
// Purpose: Demonstrate how AWS CloudFormation can automate deployment of a REST API + Lambda setup

// AWS SDK para Node.js
const AWS = require("aws-sdk");

// Import AWS Lambda Powertools modules for logging, tracing, and metrics
const { Logger } = require('@aws-lambda-powertools/logger');
const { Tracer } = require('@aws-lambda-powertools/tracer');
const { Metrics } = require('@aws-lambda-powertools/metrics');

// Criar instância do DynamoDB DocumentClient
const dynamoDb = new AWS.DynamoDB.DocumentClient();

// Initialize Powertools utilities
const logger = new Logger();   // For structured logging
const tracer = new Tracer();   // For distributed tracing
const metrics = new Metrics(); // For publishing custom metrics

// Nome da tabela
const TABLE_NAME = "TasksTable";

// Lambda handler function, invoked when the Lambda is triggered
exports.handler = async (event) => {
  // Log the incoming event for debugging and observability
  logger.info('Event received', { event });

  try {
      // Scan the 'TasksTable' in DynamoDB
      const data = await dynamoDb.scan({ TableName: TABLE_NAME }).promise();
      console.log("DynamoDB scan result:", data);
     // Log the full DynamoDB response for debugging
     logger.info('DynamoDB scan result', { data });

     // Ensure items is always an array
     const items = Array.isArray(data.Items) ? data.Items : [];

      // Record a custom metric for the number of tasks returned
      metrics.addMetric('TasksReturned', Metrics.Unit.Count, items.length);

      // Add a tracing annotation with the item count
      tracer.putAnnotation('ItemCount', items.length);

      // Return a successful response with the tasks in JSON format
      return {
          statusCode: 200,
          body: JSON.stringify({ tasks: items })
      };
  } catch (err) {
      // Log any errors that occur during the DynamoDB operation
      logger.error('Error fetching tasks', { error: err });

      // Return a generic 500 Internal Server Error response
      return {
          statusCode: 500,
          body: JSON.stringify({ message: 'Internal server error' })
      };
  }
};
